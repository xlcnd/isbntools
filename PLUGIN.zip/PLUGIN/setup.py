# -*- coding: utf-8 -*-

from setuptools import setup


setup(
    name='isbntools.contrib.plugins.dummy',
    version='0.0.1',
    author='__________________________',
    author_email='______________________________',
    url='_____________________________________',
    download_url='___________________________________',
    packages=['isbntools/contrib/plugins'],
    entry_points = {
        'isbntools.plugins': ['dummy=isbntools.contrib.plugins.dummy:query']
    },
    install_requires=["isbntools>=4.2.5","isbnlib>=3.5.5"],
    license='LGPL v3',
    description='A dummy plugin for isbntools.',
    keywords='ISBN, dummy, _____________________',
    classifiers=[
        'Programming Language :: Python',
        'Programming Language :: Python :: 2',
        'Programming Language :: Python :: 2.6',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.3',
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
        'License :: OSI Approved :: GNU Lesser General Public License v3 (LGPLv3)',
        'Operating System :: OS Independent',
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Intended Audience :: End Users/Desktop',
        'Environment :: Console',
        'Topic :: Text Processing :: General',
        'Topic :: Software Development :: Libraries :: Python Modules',
    ],
)
