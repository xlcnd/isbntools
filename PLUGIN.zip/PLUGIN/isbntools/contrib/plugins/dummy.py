# -*- coding: utf-8 -*-


from isbntools.dev import stdmeta
from isbntools.dev.bouth23 import u

def query(isbn):
    r={
       'ISBN-13': u('9780123456789'),
       'Title': u('Barbara ba'),
       'Publisher': u('Eagis'),
       'Year': u('2000'),
       'Language': u('gr'),
       'Authors': [u('Socratos'), u('Platos')]
       }
    return stdmeta(r)
