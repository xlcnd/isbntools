# -*- coding: utf-8 -*-


from isbnlib.dev import stdmeta
from isbnlib.dev._bouth23 import u


def query(isbn):
    """My fanstatic code for a new provider :) ."""
    r={
       'ISBN-13': u('9780123456789'),
       'Title': u('Barbara ba'),
       'Publisher': u('Eagis'),
       'Year': u('2000'),
       'Language': u('gr'),
       'Authors': [u('Socratos'), u('Platos')]
       }
    return stdmeta(r)
